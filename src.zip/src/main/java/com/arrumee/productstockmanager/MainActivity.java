package com.arrumee.productstockmanager;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

/**
 * Created by Asif Rahman Rumee on 12/9/2019.
 */

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void onClickStock(View view){
        Intent intent = new Intent(this, StockActivity.class);
        startActivity(intent);
    }

    public void onClickPurchases(View view){
        Intent intent = new Intent(this, PurchasesActivity.class);
        startActivity(intent);
    }

    public void onClickSales(View view){
        Intent intent = new Intent(this, SalesActivity.class);
        startActivity(intent);
    }

}
