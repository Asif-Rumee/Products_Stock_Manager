package com.arrumee.productstockmanager;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class PurchasesActivity extends AppCompatActivity {
    private SQLiteDatabase db;
    private Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_purchases);
    }

    public void onClickMakePurchase(View view){
        EditText ProductName = (EditText) findViewById(R.id.product_name);
        EditText PackSize = (EditText) findViewById(R.id.pack_size);
        EditText PurchaseQt = (EditText) findViewById(R.id.purchase_quantity);
        EditText PurchaseUnitPrice = (EditText) findViewById(R.id.purchase_unit_price);

        String prodName = ProductName.getText().toString();
        String packSize = PackSize.getText().toString();
        int purchaseQt = Integer.parseInt(PurchaseQt.getText().toString());
        int purchaseUnitPrice = Integer.parseInt(PurchaseUnitPrice.getText().toString());
        if(prodName.length() > 0  && packSize.length() > 0){
            SQLiteOpenHelper stockControllerDBHelper = new StockControllerDBHelper(this);
            try {
                db = stockControllerDBHelper.getWritableDatabase();
                cursor = db.query("STOCK",
                        new String[]{"_id", "PROD_NAME", "PACK_SIZE", "PURCHASE_QT", "PURCHASE_AMT", "SALE_QT", "SALE_AMT", "PURCHASE_PRICE", "SALE_PRICE"},
                        "PROD_NAME = ? AND PACK_SIZE = ?",
                        new String[]{prodName, packSize},
                        null, null, null);
                if(cursor.moveToFirst()) {
                    ContentValues updateValues = new ContentValues();
                    updateValues.put("PURCHASE_QT", cursor.getInt(cursor.getColumnIndex("PURCHASE_QT")) + purchaseQt);

                    db.update("STOCK",
                            updateValues,
                            "PROD_NAME = ? AND PACK_SIZE = ?",
                            new String[]{prodName, packSize});
                    Toast toast = Toast.makeText(this, "Product purchased!!!", Toast.LENGTH_SHORT);
                    toast.show();
                    cursor.close();
                    db.close();
                }
                else if(purchaseUnitPrice != 0){
                    db = stockControllerDBHelper.getWritableDatabase();

                    StockControllerDBHelper.insertStock(db, prodName, packSize, purchaseQt, (purchaseUnitPrice * purchaseQt), 0, 0, purchaseUnitPrice, 0);
                    Toast toast = Toast.makeText(this, "Product purchased!!!", Toast.LENGTH_SHORT);
                    toast.show();
                    db.close();
                }
                else{
                    Toast toast = Toast.makeText(this, "Unit Price field needs to be filled!!!", Toast.LENGTH_SHORT);
                    toast.show();
                }
            } catch(SQLiteException e) {
                Toast toast = Toast.makeText(this, "Database unavailable", Toast.LENGTH_SHORT);
                toast.show();
            }
        }
        else{
            Toast toast = Toast.makeText(this, "Fields need to be filled!!!", Toast.LENGTH_SHORT);
            toast.show();
        }

    }
}
