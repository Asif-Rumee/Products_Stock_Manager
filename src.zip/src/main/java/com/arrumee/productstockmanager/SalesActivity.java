package com.arrumee.productstockmanager;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class SalesActivity extends AppCompatActivity {

    private SQLiteDatabase db;
    private Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sales);
    }

    public void onClickMakePurchase(View view){
        EditText ProductName = (EditText) findViewById(R.id.product_name);
        EditText PackSize = (EditText) findViewById(R.id.pack_size);
        EditText SaleQt = (EditText) findViewById(R.id.sale_quantity);
        EditText SaleUnitPrice = (EditText) findViewById(R.id.sale_unit_price);

        String prodName = ProductName.getText().toString();
        String packSize = PackSize.getText().toString();
        int saleQt = Integer.parseInt(SaleQt.getText().toString());
        int saleUnitPrice = Integer.parseInt(SaleUnitPrice.getText().toString());

        SQLiteOpenHelper stockControllerDBHelper = new StockControllerDBHelper(this);
        try {
            db = stockControllerDBHelper.getWritableDatabase();
            cursor = db.query("STOCK",
                    new String[]{"_id", "PROD_NAME", "PACK_SIZE", "PURCHASE_QT", "PURCHASE_AMT", "SALE_QT", "SALE_AMT", "PURCHASE_PRICE", "SALE_PRICE"},
                    "PROD_NAME = ? AND PACK_SIZE = ?",
                    new String[]{prodName, packSize},
                    null, null, null);
            if(cursor.moveToFirst()) {
                if((cursor.getInt(cursor.getColumnIndex("SALE_QT")) + saleQt) <= cursor.getInt(cursor.getColumnIndex("PURCHASE_QT"))){
                    ContentValues updateValues = new ContentValues();
                    updateValues.put("SALE_QT", cursor.getInt(cursor.getColumnIndex("SALE_QT")) + saleQt);
                    updateValues.put("SALE_AMT", cursor.getInt(cursor.getColumnIndex("SALE_AMT")) + (saleUnitPrice * saleQt));
                    updateValues.put("SALE_PRICE", cursor.getInt(cursor.getColumnIndex("SALE_PRICE")) + saleUnitPrice);

                    db.update("STOCK",
                            updateValues,
                            "PROD_NAME = ? AND PACK_SIZE = ?",
                            new String[]{prodName, packSize});
                    Toast toast = Toast.makeText(this, "Product soldd!!!", Toast.LENGTH_SHORT);
                    toast.show();
                    cursor.close();
                    db.close();
                }
                else{
                    int remainingProducts = cursor.getInt(cursor.getColumnIndex("PURCHASE_QT")) - cursor.getInt(cursor.getColumnIndex("SALE_QT"));
                    Toast toast = Toast.makeText(this, "Only " + remainingProducts + " products remaining!!!", Toast.LENGTH_SHORT);
                    toast.show();
                    cursor.close();
                    db.close();
                }

            }
            else{
                Toast toast = Toast.makeText(this, "Product not available to sell!!!", Toast.LENGTH_SHORT);
                toast.show();
                cursor.close();
                db.close();
            }
        } catch(SQLiteException e) {
            Toast toast = Toast.makeText(this, "Database unavailable", Toast.LENGTH_SHORT);
            toast.show();
        }

    }
}
