package com.arrumee.productstockmanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Asif Rahman Rumee on 12/8/2019.
 */

public class StockControllerDBHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "stockcontroller"; // the name of our database
    private static final int DB_VERSION = 1; // the version of the database

    StockControllerDBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        updateMyDatabase(db, 0, DB_VERSION);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    static void insertStock(SQLiteDatabase db, String ProdName, String PackSize, int PurchaseQt, int PurchaseAmt, int SaleQt, int SaleAmt, int PPrice, int SPrice) {
        ContentValues stockValues = new ContentValues();
        stockValues.put("PROD_NAME", ProdName);
        stockValues.put("PACK_SIZE", PackSize);
        stockValues.put("PURCHASE_QT", PurchaseQt);
        stockValues.put("PURCHASE_AMT", PurchaseAmt);
        stockValues.put("SALE_QT", SaleQt);
        stockValues.put("SALE_AMT", SaleAmt);
        stockValues.put("BALANCE", PurchaseQt - SaleQt);
        stockValues.put("PURCHASE_PRICE", PPrice);
        stockValues.put("SALE_PRICE", SPrice);
        stockValues.put("PROFIT", (SPrice - PPrice) * SaleQt);
        stockValues.put("BPA", PPrice * (PurchaseQt - SaleQt));
        db.insert("STOCK", null, stockValues);
    }

    private void updateMyDatabase(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 1) {
            db.execSQL("CREATE TABLE STOCK (_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + "PROD_NAME TEXT, "
                    + "PACK_SIZE TEXT, "
                    + "PURCHASE_QT INTEGER, "
                    + "PURCHASE_AMT INTEGER, "
                    + "SALE_QT INTEGER, "
                    + "SALE_AMT INTEGER, "
                    + "BALANCE INTEGER, "
                    + "PURCHASE_PRICE INTEGER, "
                    + "SALE_PRICE INTEGER, "
                    + "PROFIT INTEGER, "
                    + "BPA INTEGER);");
            insertStock(db, "HP RACER 4 20W50 MA2 4T 1L", "1X10", 400, 126720, 397, 137465, 317, 346);
            insertStock(db, "HP RACER 4 20W40 MA2 4T 1L", "1X10", 250, 79200, 214, 74885, 317, 350);
            insertStock(db, "HP RACER 4 10W30 MA2 4T 1L", "1X10", 60, 41712, 22, 16141, 695, 734);
        }
    }
}