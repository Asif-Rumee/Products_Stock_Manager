package com.arrumee.productstockmanager;

/**
 * Created by Asif Rahman Rumee on 12/9/2019.
 */

public class Stock {
    private int sL;
    private String prodName;
    private String packSize;
    private int purchaseQt;
    private int purchaseAmt;
    private int saleQt;
    private int saleAmt;
    private int balance;
    private int purchasePrice;
    private int salePrice;
    private int profit;
    private int bpa;

    public Stock(int sL, String prodName, String packSize, int purchaseQt, int purchaseAmt, int saleQt, int saleAmt, int purchasePrice, int salePrice) {
        this.sL = sL;
        this.prodName = prodName;
        this.packSize = packSize;
        this.purchaseQt = purchaseQt;
        this.purchaseAmt = purchaseAmt;
        this.saleQt = saleQt;
        this.saleAmt = saleAmt;
        this.purchasePrice = purchasePrice;
        this.salePrice = salePrice;
        this.balance = this.purchaseQt - this.saleQt;
        this.profit = (this.salePrice - this.purchasePrice) * this.saleQt;
        this.bpa = this.purchasePrice * this.balance;
    }

    public int getsL() {
        return sL;
    }

    public void setsL(int sL) {
        this.sL = sL;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public String getPackSize() {
        return packSize;
    }

    public void setPackSize(String packSize) {
        this.packSize = packSize;
    }

    public int getPurchaseQt() {
        return purchaseQt;
    }

    public void setPurchaseQt(int purchaseQt) {
        this.purchaseQt = purchaseQt;
    }

    public int getPurchaseAmt() {
        return purchaseAmt;
    }

    public void setPurchaseAmt(int purchaseAmt) {
        this.purchaseAmt = purchaseAmt;
    }

    public int getSaleQt() {
        return saleQt;
    }

    public void setSaleQt(int saleQt) {
        this.saleQt = saleQt;
    }

    public int getSaleAmt() {
        return saleAmt;
    }

    public void setSaleAmt(int saleAmt) {
        this.saleAmt = saleAmt;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public int getPurchasePrice() {
        return purchasePrice;
    }

    public void setPurchasePrice(int purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    public int getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(int salePrice) {
        this.salePrice = salePrice;
    }

    public int getProfit() {
        return profit;
    }

    public void setProfit(int profit) {
        this.profit = profit;
    }

    public int getBpa() {
        return bpa;
    }

    public void setBpa(int bpa) {
        this.bpa = bpa;
    }
}
