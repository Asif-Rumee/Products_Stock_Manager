package com.arrumee.productstockmanager;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Asif Rahman Rumee on 12/9/2019.
 */

public class StockAdapter extends ArrayAdapter<Stock> {
    private Context mContext;
    private int mResource;

    public StockAdapter(Context context, int resource, ArrayList<Stock> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        String sL = String.valueOf(getItem(position).getsL());
        String prodName = getItem(position).getProdName();
        String packSize = getItem(position).getPackSize();
        String purchaseQt = String.valueOf(getItem(position).getPurchaseQt());
        String purchaseAmt = String.valueOf(getItem(position).getPurchaseAmt());
        String saleQt = String.valueOf(getItem(position).getSaleQt());
        String saleAmt = String.valueOf(getItem(position).getSaleAmt());
        String balance = String.valueOf(getItem(position).getBalance());
        String pPrice = String.valueOf(getItem(position).getPurchasePrice());
        String sPrice = String.valueOf(getItem(position).getSalePrice());
        String profit = String.valueOf(getItem(position).getProfit());
        String bpa = String.valueOf(getItem(position).getBpa());

        //Stock stock = new Stock(sL, prodName, packSize, purchaseQt, purchaseAmt, saleQt, saleAmt);

        LayoutInflater inflater = LayoutInflater.from(mContext);
        convertView = inflater.inflate(mResource, parent, false);

        TextView SL = (TextView) convertView.findViewById(R.id.textViewSL);
        TextView ProdName = (TextView) convertView.findViewById(R.id.textViewProdName);
        TextView PackSize = (TextView) convertView.findViewById(R.id.textViewPackSize);
        TextView PurchaseQt = (TextView) convertView.findViewById(R.id.textViewPurchaseQt);
        TextView PurchaseAmt = (TextView) convertView.findViewById(R.id.textViewPurchaseAmt);
        TextView SaleQt = (TextView) convertView.findViewById(R.id.textViewSaleQt);
        TextView SaleAmt = (TextView) convertView.findViewById(R.id.textViewSaleAmt);
        TextView Balance = (TextView) convertView.findViewById(R.id.textViewBalance);
        TextView PPrice = (TextView) convertView.findViewById(R.id.textViewPurchasePrice);
        TextView SPrice = (TextView) convertView.findViewById(R.id.textViewSalePrice);
        TextView Profit = (TextView) convertView.findViewById(R.id.textViewProfit);
        TextView BPA = (TextView) convertView.findViewById(R.id.textViewBPA);

        SL.setText(sL);
        ProdName.setText(prodName);
        PackSize.setText(packSize);
        PurchaseQt.setText(purchaseQt);
        PurchaseAmt.setText(purchaseAmt);
        SaleQt.setText(saleQt);
        SaleAmt.setText(saleAmt);
        Balance.setText(balance);
        PPrice.setText(pPrice);
        SPrice.setText(sPrice);
        Profit.setText(profit);
        BPA.setText(bpa);

        return convertView;
    }
}
