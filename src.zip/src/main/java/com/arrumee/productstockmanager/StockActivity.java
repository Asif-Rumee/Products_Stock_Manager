package com.arrumee.productstockmanager;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by Asif Rahman Rumee on 12/9/2019.
 */

public class StockActivity extends AppCompatActivity {
    private SQLiteDatabase db;
    private Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stock);

        ListView mListView = (ListView) findViewById(R.id.MainActivityListView);
        ArrayList<Stock> stockList = new ArrayList<>();

        SQLiteOpenHelper stockControllerDBHelper = new StockControllerDBHelper(this);
        try {
            db = stockControllerDBHelper.getReadableDatabase();
            cursor = db.query("STOCK",
                    new String[]{"_id", "PROD_NAME", "PACK_SIZE", "PURCHASE_QT", "PURCHASE_AMT", "SALE_QT", "SALE_AMT", "PURCHASE_PRICE", "SALE_PRICE"},

                    null, null, null, null, null);
            if(cursor.moveToFirst()){
                do {
                    stockList.add(new Stock(cursor.getInt(0), cursor.getString(1), cursor.getString(2), cursor.getInt(3), cursor.getInt(4), cursor.getInt(5), cursor.getInt(6), cursor.getInt(7), cursor.getInt(8)));
                } while (cursor.moveToNext());
            }

        } catch(SQLiteException e) {
            Toast toast = Toast.makeText(this, "Database unavailable", Toast.LENGTH_SHORT);
            toast.show();
        }

        StockAdapter stockAdapter = new StockAdapter(this, R.layout.stock_view_adapter, stockList);
        mListView.setAdapter(stockAdapter);
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        cursor.close();
        db.close();
    }
}
